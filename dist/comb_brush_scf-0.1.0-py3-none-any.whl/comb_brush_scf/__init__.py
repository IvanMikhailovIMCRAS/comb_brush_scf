from .script_creation import (script_creation, mol_script)
import os
os.system("chmod 777 data/sfbox")
__all__ = ["script_creation", "mol_script"]
